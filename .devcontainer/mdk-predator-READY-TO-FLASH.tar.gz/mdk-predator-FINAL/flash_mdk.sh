#!/bin/bash
# Flash Script für MDK Predator Firmware
# Verwendung: ./flash_mdk.sh [PORT]

set -e

PORT=${1:-/dev/ttyUSB0}

echo "╔════════════════════════════════════════════════════════╗"
echo "║      MDK Predator ESP32-S3 Flash Utility              ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# Check if binary exists
if [ ! -f "mdk-predator.bin" ]; then
    echo "❌ Error: mdk-predator.bin not found!"
    echo ""
    echo "Please ensure mdk-predator.bin is in the same directory"
    exit 1
fi

# Check if esptool is available
if ! command -v esptool.py &> /dev/null; then
    echo "❌ Error: esptool.py not found!"
    echo ""
    echo "Install with: pip install esptool"
    exit 1
fi

# Check if device exists
if [ ! -e "$PORT" ]; then
    echo "⚠️  Warning: Device $PORT not found!"
    echo ""
    echo "Available devices:"
    ls -1 /dev/ttyUSB* /dev/ttyACM* 2>/dev/null || echo "  No USB serial devices found"
    echo ""
    echo "Usage: $0 [PORT]"
    echo "Example: $0 /dev/ttyACM0"
    exit 1
fi

echo "📋 Flash Information:"
echo "  Port: $PORT"
echo "  Chip: ESP32-S3"
echo "  Binary: mdk-predator.bin ($(stat -f%z mdk-predator.bin 2>/dev/null || stat -c%s mdk-predator.bin) bytes)"
echo ""

echo "⚠️  IMPORTANT:"
echo "  1. Disconnect MDK module from PortaPack"
echo "  2. Connect MDK module via USB-C cable"
echo "  3. Press BOOT + RESET if auto-flash fails"
echo ""

read -p "Ready to flash? (y/N) " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 0
fi

echo ""
echo "🔥 Flashing firmware..."
echo ""

# Flash command
esptool.py --chip esp32s3 \
    --port "$PORT" \
    --baud 460800 \
    --before default_reset \
    --after hard_reset \
    write_flash -z \
    --flash_mode dio \
    --flash_freq 80m \
    --flash_size detect \
    0x0 bootloader.bin \
    0x8000 partition-table.bin \
    0x10000 mdk-predator.bin

if [ $? -eq 0 ]; then
    echo ""
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║              ✅ FLASH SUCCESSFUL!                      ║"
    echo "╚════════════════════════════════════════════════════════╝"
    echo ""
    echo "Next Steps:"
    echo "  1. Disconnect USB-C from MDK module"
    echo "  2. Connect MDK module to PortaPack H4M"
    echo "  3. Power on PortaPack"
    echo "  4. Test I2C: Settings → Hardware → I2C Scan"
    echo "     Should show: 0x51 ✓"
    echo ""
    echo "Monitor serial output:"
    echo "  esptool.py --port $PORT --baud 115200 read_flash 0 0"
    echo ""
else
    echo ""
    echo "❌ Flash failed!"
    echo ""
    echo "Troubleshooting:"
    echo "  - Check USB cable (must support data)"
    echo "  - Try holding BOOT button while connecting"
    echo "  - Try different USB port"
    echo "  - Check permissions: sudo usermod -a -G dialout \$USER"
    echo ""
    exit 1
fi
