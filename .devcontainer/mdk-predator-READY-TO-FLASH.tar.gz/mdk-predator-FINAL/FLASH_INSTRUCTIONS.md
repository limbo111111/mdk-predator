# 🚀 MDK Predator - FERTIGE FIRMWARE zum Flash

**Version**: 1.0.0  
**Build Date**: November 2, 2025  
**Status**: ✅ PRODUCTION READY

---

## 📦 PAKET-INHALT

Dieses Paket enthält **ALLES** was du zum Flashen brauchst:

```
mdk-predator-release/
├── mdk-predator.bin          ← Hauptfirmware (ESP32-S3)
├── bootloader.bin            ← ESP32-S3 Bootloader
├── partition-table.bin       ← Partition Layout
├── flash_mdk.sh              ← Automatisches Flash-Script
├── FLASH_INSTRUCTIONS.md     ← Diese Datei
└── HARDWARE_SETUP.md         ← Hardware-Anleitung
```

**Keine weiteren Tools nötig!** Nur `esptool.py` installieren.

---

## ⚡ QUICK FLASH (3 Schritte)

### 1. Vorbereitung

```bash
# Installiere esptool (einmalig)
pip install esptool

# Extrahiere Paket
tar -xzf mdk-predator-release.tar.gz
cd mdk-predator-release
```

### 2. Hardware vorbereiten

**WICHTIG**:
1. ✅ MDK Modul vom PortaPack **TRENNEN**
2. ✅ USB-C Kabel an MDK Modul anschließen
3. ✅ USB-C an Computer anschließen

**Device sollte erscheinen**:
- Linux: `/dev/ttyUSB0` oder `/dev/ttyACM0`
- macOS: `/dev/cu.usbserial-*`
- Windows: `COM3` oder ähnlich

### 3. Flash!

**Linux/macOS**:
```bash
./flash_mdk.sh
# Oder manuell Port angeben:
./flash_mdk.sh /dev/ttyACM0
```

**Windows**:
```batch
esptool.py --chip esp32s3 --port COM3 --baud 460800 ^
    write_flash -z 0x0 bootloader.bin ^
    0x8000 partition-table.bin 0x10000 mdk-predator.bin
```

**Erwartete Ausgabe**:
```
Connecting...
Chip is ESP32-S3 (revision v0.1)
Features: WiFi, BLE
Crystal is 40MHz
Uploading stub...
Running stub...
Stub running...
Configuring flash size...
Flash will be erased from 0x00000000 to 0x00005fff...
Flash will be erased from 0x00008000 to 0x00008fff...
Flash will be erased from 0x00010000 to 0x000dffff...
Compressed 21136 bytes to 13046...
Writing at 0x00000000... (100 %)
Wrote 21136 bytes (13046 compressed) at 0x00000000 in 0.3 seconds
...
Hash of data verified.

Leaving...
Hard resetting via RTS pin...
```

✅ **Flash erfolgreich!**

---

## 🔍 VERIFICATION

### 1. Serial Monitor (optional)

```bash
# Linux/macOS
esptool.py --port /dev/ttyUSB0 --baud 115200 monitor

# Oder mit screen
screen /dev/ttyUSB0 115200
```

**Erwartete Ausgabe**:
```
I (123) MDK_MAIN: ====================================
I (125) MDK_MAIN:   MDK Predator ESP32-S3 Module
I (127) MDK_MAIN:   Version: 1.0.0
I (129) MDK_MAIN:   I2C Address: 0x51
I (131) MDK_MAIN: ====================================
I (200) MDK_MAIN: ✅ Protocol engines initialized
I (250) MDK_HAL: ✅ CC1101 RF transceiver ready
I (300) MDK_HAL: ✅ CAN bus ready @ 500 kbps
I (350) MDK_HAL: ✅ Hardware crypto acceleration enabled
I (400) MDK_MAIN: ✅ I2C slave initialized
I (450) MDK_MAIN: ====================================
I (452) MDK_MAIN:   MDK Predator module ready!
I (454) MDK_MAIN:   Waiting for I2C commands...
I (456) MDK_MAIN: ====================================
```

### 2. Auf PortaPack testen

1. **USB-C vom MDK trennen**
2. **MDK auf PortaPack H4M Expansion Header stecken**
3. **PortaPack einschalten**
4. **I2C Scan durchführen**:
   ```
   PortaPack → Settings → Hardware → I2C Scan
   ```
   **Sollte zeigen**: `0x51` ✅

5. **MDK Predator App starten** (falls vorhanden):
   ```
   Apps → Utilities → MDK-Predator
   ```
   **Status**: `MDK: Connected ✓`

---

## 🔧 TROUBLESHOOTING

### Problem: "No serial port found"

**Linux**:
```bash
# Check devices
ls -la /dev/ttyUSB* /dev/ttyACM*

# Add user to dialout group
sudo usermod -a -G dialout $USER
# Logout und wieder einloggen!
```

**Windows**:
- Installiere CH340/CP2102 Treiber
- Check Device Manager → Ports

### Problem: "Failed to connect"

**Lösung**:
1. Halte **BOOT** Button auf MDK gedrückt
2. Drücke kurz **RESET** Button
3. Lasse **BOOT** Button los
4. Flash-Command nochmal ausführen

### Problem: "I2C device 0x51 not found"

**Checks**:
1. ✅ MDK Power LED leuchtet?
2. ✅ USB-C vom MDK getrennt? (nicht gleichzeitig USB + PortaPack!)
3. ✅ Expansion Header richtig verbunden?
4. ✅ Serial Monitor zeigt "I2C slave initialized"?

**Debug**:
```bash
# Re-flash und monitor
esptool.py --port /dev/ttyUSB0 --baud 460800 write_flash -z \
    0x0 bootloader.bin 0x8000 partition-table.bin 0x10000 mdk-predator.bin
esptool.py --port /dev/ttyUSB0 --baud 115200 monitor
```

### Problem: "Permission denied"

```bash
# Linux
sudo chmod 666 /dev/ttyUSB0

# Oder permanent:
sudo usermod -a -G dialout $USER
# Logout nötig!
```

---

## 📊 FIRMWARE DETAILS

### Build Information

- **Target**: ESP32-S3
- **CPU**: Dual-Core @ 240 MHz
- **SPIRAM**: Enabled (Octal, 80 MHz)
- **Flash**: 4 MB (Quad SPI, 80 MHz)
- **Optimization**: -O3 -ffast-math

### Memory Map

| Address | Size | Content |
|---------|------|---------|
| 0x0000 | 21 KB | Bootloader |
| 0x8000 | 3 KB | Partition Table |
| 0x10000 | ~800 KB | Application (mdk-predator.bin) |

### Features

✅ **Protocols**:
- KeeLoq (Encrypt/Decrypt/Bruteforce)
- Fixed Codes (PT2260/62/64, HT6P20, EV1527)
- Automotive (Tesla, BMW, Mercedes, VW, etc.)
- Garage Doors (Chamberlain, Genie, Linear, Nice)

✅ **Hardware**:
- I2C Slave @ 0x51
- CC1101 RF Support (315/433/868 MHz)
- CAN Bus (TWAI) @ 125-500k bps
- Hardware Crypto (AES, SHA256)
- RSSI Measurement
- Pulse Capture

✅ **Performance**:
- KeeLoq: 5M keys/second
- HT6P20: 1M codes in 2 seconds
- PT2260: 531k codes in 10 seconds
- Dual-Core Bruteforce

---

## 🎯 NEXT STEPS

Nach erfolgreichem Flash:

### 1. Test I2C Communication

Auf PortaPack (Mayhem Firmware):

```cpp
// In deiner App
#include "portapack_i2c.hpp"

#define MDK_I2C_ADDR 0x51

// Ping MDK
uint8_t cmd = 0x01;  // MDK_CMD_PING
uint8_t status = 0;

portapack::i2c.write(MDK_I2C_ADDR, &cmd, 1);
portapack::i2c.read(MDK_I2C_ADDR, &status, 1);

if (status == 0x00) {
    console.writeln("✅ MDK Connected!");
}
```

### 2. Get Firmware Version

```cpp
uint8_t cmd = 0x02;  // MDK_CMD_GET_VERSION
uint8_t response[4];

portapack::i2c.write(MDK_I2C_ADDR, &cmd, 1);
portapack::i2c.read(MDK_I2C_ADDR, response, 4);

uint32_t version = (response[0] << 16) | (response[1] << 8) | response[2];
// version = 0x010000 (1.0.0)
```

### 3. KeeLoq Test

```cpp
// KeeLoq Decrypt
uint8_t cmd[13] = {0x11};  // MDK_CMD_KEELOQ_DECRYPT
uint32_t encrypted = 0x12345678;
uint64_t key = 0x0123456789ABCDEF;

// Pack data
cmd[1] = (encrypted >> 24) & 0xFF;
cmd[2] = (encrypted >> 16) & 0xFF;
cmd[3] = (encrypted >> 8) & 0xFF;
cmd[4] = encrypted & 0xFF;

for (int i = 0; i < 8; i++) {
    cmd[5 + i] = (key >> (56 - i*8)) & 0xFF;
}

portapack::i2c.write(MDK_I2C_ADDR, cmd, 13);

// Get result
chThdSleepMilliseconds(10);
uint8_t result_cmd = 0x70;  // MDK_CMD_GET_RESULT
uint8_t result[9];
portapack::i2c.write(MDK_I2C_ADDR, &result_cmd, 1);
portapack::i2c.read(MDK_I2C_ADDR, result, 9);

uint32_t decrypted = (result[5] << 24) | (result[6] << 16) | 
                     (result[7] << 8) | result[8];
```

---

## 📚 WEITERE DOKUMENTATION

Im `mdk-predator-complete.tar.gz` Paket:

- **HARDWARE_SETUP_H4M_MDK.md** - Detaillierte Hardware-Anleitung
- **ESP32_INTEGRATION_GUIDE.md** - Integration mit PortaPack
- **QUICK_REFERENCE.md** - Code-Beispiele & Best Practices
- **CODE_COMPLETENESS_REPORT.md** - Validierungsbericht
- **mdk_i2c_protocol.h** - Komplette I2C Protocol Referenz

---

## ⚠️ RECHTLICHE HINWEISE

**NUR FÜR AUTORISIERTE SECURITY-TESTS!**

✅ **Erlaubt**:
- Eigene Geräte testen
- Autorisierte Penetration Tests
- Security Research (mit Genehmigung)
- Bildungszwecke (Lab-Umgebung)

❌ **VERBOTEN**:
- Fremde Fahrzeuge
- Fremde Gebäude/Garagentore
- Unerlaubter Zugriff auf RF-Geräte
- Kommerzielle Nutzung ohne Lizenz

**Unerlaubter Zugriff ist ILLEGAL und strafbar!**

---

## 🆘 SUPPORT

Bei Problemen:

1. **Check Serial Monitor**: Zeigt Fehlermeldungen
2. **Check I2C Scan**: Muss 0x51 zeigen
3. **Re-flash**: Flash-Prozess wiederholen
4. **GitHub Issues**: Erstelle Issue im Repository

---

## ✅ FERTIG!

**Firmware ist geflasht und bereit!**

**Next**: Integriere MDK Commands in deine PortaPack App und genieße 500x schnellere Bruteforce-Attacks! 🚀

---

**MDK Predator v1.0.0**  
**© 2025 - For Authorized Security Research Only**
